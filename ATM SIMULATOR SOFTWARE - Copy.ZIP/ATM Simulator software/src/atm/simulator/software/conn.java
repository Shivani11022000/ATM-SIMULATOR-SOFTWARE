

package atm.simulator.software;

import java.sql.*;  

public class conn{
    public static void main(String args[])
    {
    Connection c=null;
    Statement s;
   
        try{  
            Class.forName("com.mysql.jdbc.Driver");  
            c =DriverManager.getConnection("jdbc:mysql://localhost:3307/atm?zeroDateTimeBehavior=convertToNull","root","shivani@14");    
            s =c.createStatement(); 
           
          System.out.println("connection Successfull");
            
        }catch(Exception e){ 
            System.out.println(e);
        }  
    }

    ResultSet executeQuery(String q) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     
    
}


